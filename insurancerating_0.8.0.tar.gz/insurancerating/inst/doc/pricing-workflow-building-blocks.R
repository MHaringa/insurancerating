## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(insurancerating)

## -----------------------------------------------------------------------------
fa <- factor_analysis(
  MTPL,
  risk_factors = "zip",
  claim_count = "nclaims",
  claim_amount = "amount",
  exposure = "exposure"
)

head(fa)

## -----------------------------------------------------------------------------
outlier_histogram(
  MTPL2,
  x = "premium",
  upper = 100,
  density = FALSE
)

## ----eval = FALSE-------------------------------------------------------------
# thresholds <- assess_excess_threshold(
#   claims,
#   claim_amount = "claim_amount",
#   thresholds = c(50000, 100000, 150000),
#   exposure = "earned_exposure",
#   group = "sector"
# )
# 
# autoplot(thresholds, y = "premium_impact")

## ----eval = FALSE-------------------------------------------------------------
# excess <- calculate_excess_loss(
#   claims,
#   claim_amount = "claim_amount",
#   threshold = 100000
# )

## ----eval = FALSE-------------------------------------------------------------
# allocation <- allocate_excess_loss(
#   excess,
#   excess_amount = "excess_claim_amount",
#   allocation_weight = "earned_exposure",
#   risk_factor = "sector",
#   allocation = "partial",
#   preserve_total_excess = TRUE
# )
# 
# summary(allocation, compare_to_empirical = TRUE)
# autoplot(allocation, y = "allocated_loading")
# autoplot(allocation, y = "credibility")

## ----eval = FALSE-------------------------------------------------------------
# excess$base_premium <- excess$technical_premium
# priced <- apply_excess_loading(
#   excess,
#   allocation,
#   base_premium = "base_premium"
# )

## -----------------------------------------------------------------------------
age_gam <- risk_factor_gam(
  data = MTPL,
  claim_count = "nclaims",
  risk_factor = "age_policyholder",
  exposure = "exposure"
)

age_segments <- derive_tariff_segments(age_gam)
age_segments

## -----------------------------------------------------------------------------
portfolio <- MTPL |>
  add_tariff_segments(age_segments, name = "age_policyholder_segment")

head(portfolio[, c("age_policyholder", "age_policyholder_segment")])

## -----------------------------------------------------------------------------
portfolio$zip <- as.factor(portfolio$zip)

freq_model <- glm(
  nclaims ~ zip + age_policyholder_segment + offset(log(exposure)),
  family = poisson(),
  data = portfolio
)

rt <- rating_table(
  freq_model,
  model_data = portfolio,
  exposure = "exposure"
)

head(rt$df)

## -----------------------------------------------------------------------------
zip_experience <- factor_analysis(
  portfolio,
  risk_factors = "zip",
  claim_count = "nclaims",
  exposure = "exposure"
)

rt |>
  add_observed_experience(zip_experience, metric = "frequency") |>
  autoplot(risk_factors = "zip")

## ----eval = FALSE-------------------------------------------------------------
# refined_model <- prepare_refinement(freq_model) |>
#   add_smoothing(
#     model_variable = "age_policyholder_segment",
#     source_variable = "age_policyholder",
#     weights = "exposure"
#   ) |>
#   add_restriction(restrictions) |>
#   refit()

## -----------------------------------------------------------------------------
check_overdispersion(freq_model)

## ----eval = FALSE-------------------------------------------------------------
# check_residuals(freq_model) |>
#   autoplot()


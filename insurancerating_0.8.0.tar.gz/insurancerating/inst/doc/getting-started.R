## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----warning = FALSE, message = FALSE-----------------------------------------

library(insurancerating)
library(dplyr)

head(MTPL2)


## -----------------------------------------------------------------------------

fa <- factor_analysis(
  MTPL,
  risk_factors = "zip",
  claim_count = "nclaims",
  exposure = "exposure",
  claim_amount = "amount"
)

fa


## -----------------------------------------------------------------------------

autoplot(fa, metrics = c("exposure", "frequency", "risk_premium"))


## -----------------------------------------------------------------------------

age_freq <- risk_factor_gam(
  data = MTPL,
  risk_factor = "age_policyholder",
  claim_count = "nclaims",
  exposure = "exposure"
)

autoplot(age_freq, show_observations = TRUE)


## -----------------------------------------------------------------------------

age_segments <- derive_tariff_segments(age_freq)
autoplot(age_segments)


## -----------------------------------------------------------------------------

dat <- MTPL |>
  add_tariff_segments(age_segments, name = "age_cat") |>
  mutate(across(where(is.character), as.factor)) |>
  mutate(across(where(is.factor), ~ set_reference_level(., exposure)))


## -----------------------------------------------------------------------------

mod_freq <- glm(
  nclaims ~ age_cat,
  offset = log(exposure),
  family = poisson(),
  data = dat
)


## -----------------------------------------------------------------------------

mod_sev <- glm(
  amount ~ age_cat,
  weights = nclaims,
  family = Gamma(link = "log"),
  data = dat |> filter(amount > 0)
)


## -----------------------------------------------------------------------------

premium_df <- dat |>
  add_prediction(mod_freq, mod_sev) |>
  mutate(premium = pred_nclaims_mod_freq * pred_amount_mod_sev)

head(premium_df)


## -----------------------------------------------------------------------------

burn_unrestricted <- glm(
  premium ~ age_cat + zip,
  weights = exposure,
  family = Gamma(link = "log"),
  data = premium_df
)


## -----------------------------------------------------------------------------

rt <- rating_table(burn_unrestricted)
rt


## -----------------------------------------------------------------------------

rating_table(burn_unrestricted) |>
  autoplot()


## -----------------------------------------------------------------------------

model_performance(mod_freq)


## -----------------------------------------------------------------------------

bp <- bootstrap_performance(mod_freq, dat, n_resamples = 50, show_progress = FALSE)
autoplot(bp)


## ----eval = FALSE-------------------------------------------------------------
# 
# factor_analysis()             # analyse portfolio behaviour
# risk_factor_gam()              # analyse continuous variables
# derive_tariff_segments()        # derive tariff segments
# glm()                         # estimate pricing models
# rating_table()                # interpret fitted coefficients
# bootstrap_performance()       # assess stability
# prepare_refinement()          # refine tariff structure if needed
# 


## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------

library(insurancerating)
library(dplyr)

df <- MTPL2 |>
  mutate(across(c(area), as.factor)) |>
  mutate(across(c(area), ~ set_reference_level(., exposure)))

mod1 <- glm(
  nclaims ~ area,
  offset = log(exposure),
  family = poisson(),
  data = df
)

mod2 <- glm(
  nclaims ~ area + premium,
  offset = log(exposure),
  family = poisson(),
  data = df
)


## -----------------------------------------------------------------------------

model_performance(mod1, mod2)


## -----------------------------------------------------------------------------

rating_table(mod1, mod2, model_data = df, exposure = "exposure") |>
  autoplot()


## -----------------------------------------------------------------------------

bootstrap_performance(mod1, df, n_resamples = 100, show_progress = FALSE) |>
  autoplot()


## -----------------------------------------------------------------------------

check_overdispersion(mod1)


## -----------------------------------------------------------------------------

check_residuals(mod1, n_simulations = 600) |>
  autoplot()


## -----------------------------------------------------------------------------

grid <- rating_grid(mod1)
head(grid)


## ----eval = FALSE-------------------------------------------------------------
# 
# model_performance(...)        # compare fitted models
# rating_table(...) |> autoplot()   # inspect coefficient structure
# bootstrap_performance(...)    # assess predictive stability
# check_overdispersion(...)     # assess dispersion
# check_residuals(...)          # inspect residual behaviour
# rating_grid(...)              # review model-point structure
# 


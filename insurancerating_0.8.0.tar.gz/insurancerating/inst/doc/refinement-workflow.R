## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----message = FALSE, warning = FALSE-----------------------------------------

library(insurancerating)
library(dplyr)

age_policyholder_frequency <- risk_factor_gam(
  data = MTPL,
  claim_count = "nclaims",
  risk_factor = "age_policyholder",
  exposure = "exposure"
)

age_segments_freq <- derive_tariff_segments(age_policyholder_frequency)

dat <- MTPL |>
  add_tariff_segments(age_segments_freq, name = "age_policyholder_freq_cat") |>
  mutate(across(where(is.character), as.factor)) |>
  mutate(across(where(is.factor), ~ set_reference_level(., exposure)))

freq <- glm(
  nclaims ~ bm + age_policyholder_freq_cat,
  offset = log(exposure),
  family = poisson(),
  data = dat
)

sev <- glm(
  amount ~ zip,
  weights = nclaims,
  family = Gamma(link = "log"),
  data = dat |> filter(amount > 0)
)

premium_df <- dat |>
  add_prediction(freq, sev) |>
  mutate(premium = pred_nclaims_freq * pred_amount_sev)

burn_unrestricted <- glm(
  premium ~ zip + bm + age_policyholder_freq_cat,
  weights = exposure,
  family = Gamma(link = "log"),
  data = premium_df
)


## -----------------------------------------------------------------------------

rating_table(burn_unrestricted)

rating_table(burn_unrestricted) |>
  autoplot()


## -----------------------------------------------------------------------------

ref <- prepare_refinement(burn_unrestricted)
ref


## -----------------------------------------------------------------------------

ref <- ref |>
  add_smoothing(
    model_variable = "age_policyholder_freq_cat",
    source_variable = "age_policyholder",
    breaks = seq(18, 95, 5),
    weights = "exposure"
  )


## -----------------------------------------------------------------------------

print(ref)
autoplot(ref, variable = "age_policyholder_freq_cat")


## -----------------------------------------------------------------------------

zip_df <- data.frame(
  zip = c(0, 1, 2, 3),
  zip_adj = c(0.8, 0.9, 1.0, 1.2)
)

ref <- ref |>
  add_restriction(restrictions = zip_df)


## -----------------------------------------------------------------------------

autoplot(ref, variable = "zip")


## ----eval = FALSE-------------------------------------------------------------
# 
# relativities_activity <- relativities(
#   split_level(
#     "construction",
#     c("residential_construction", "commercial_construction"),
#     c(1.00, 1.15)
#   )
# )
# 
# ref <- ref |>
#   add_relativities(
#     model_variable = "business_activity",
#     split_variable = "business_activity_split",
#     relativities = relativities_activity,
#     exposure = "exposure",
#     normalize = TRUE
#   )
# 

## -----------------------------------------------------------------------------

burn_refined <- refit(ref)


## -----------------------------------------------------------------------------

rating_table(burn_refined)


## -----------------------------------------------------------------------------

rating_table(burn_refined) |>
  autoplot()


## -----------------------------------------------------------------------------

md <- extract_model_data(burn_refined)
head(md)


## -----------------------------------------------------------------------------

grid <- rating_grid(burn_refined)
head(grid)


## -----------------------------------------------------------------------------

zip_df <- data.frame(
  zip = c(0, 1, 2, 3),
  zip_adj = c(0.8, 0.9, 1.0, 1.2)
)

burn_refined <- prepare_refinement(burn_unrestricted) |>
  add_smoothing(
    model_variable = "age_policyholder_freq_cat",
    source_variable = "age_policyholder",
    breaks = seq(18, 95, 5),
    weights = "exposure"
  ) |>
  add_restriction(zip_df) |>
  refit()

rating_table(burn_refined)

rating_table(burn_refined) |>
  autoplot()


## ----eval = FALSE-------------------------------------------------------------
# 
# burn_refined_old <- burn_unrestricted |>
#   smooth_coef(
#     x_cut = "age_policyholder_freq_man",
#     x_org = "age_policyholder",
#     breaks = seq(18, 95, 5)
#   ) |>
#   restrict_coef(zip_df) |>
#   refit_glm()
# 

## ----eval = FALSE-------------------------------------------------------------
# 
# prepare_refinement() |> add_*() |> refit()
# 


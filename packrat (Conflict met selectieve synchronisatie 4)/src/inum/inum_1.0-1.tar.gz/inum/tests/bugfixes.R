
library("inum")

### there was a warning; reported by Fabian Scheipl
x <- 1:2 + .1
inum(data.frame(x = x))




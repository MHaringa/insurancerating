#' @import stats utils tools
NULL

os = .Platform$OS.type

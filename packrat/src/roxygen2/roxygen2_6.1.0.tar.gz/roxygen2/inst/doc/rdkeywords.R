## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(comment = "#>", collapse = TRUE)

## ------------------------------------------------------------------------
cat(readLines(file.path(R.home("doc"), "KEYWORDS")), sep = "\n")



# 1.1.2

Maintainence release, no user visible changes

# 1.1.1

Maintainence release, no user visible changes

# 1.1.0

* Fallbacks, instead of errors, #2

# 1.0.0

First release

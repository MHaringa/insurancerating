Oct 2017: Updated en_US / en_GB from
  https://extensions.libreoffice.org/extensions/english-dictionaries/2017-11.01

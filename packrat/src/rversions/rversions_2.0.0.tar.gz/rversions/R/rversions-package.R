#' @details The R version numbers and dates are extracted from the
#' main R SVN repository at <http://svn.r-project.org/R/>.
#' @keywords internal
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
## usethis namespace: end
NULL

#' @keywords internal
#' @import rlang
#' @useDynLib vctrs, .registration = TRUE
"_PACKAGE"

#' @keywords internal
"_PACKAGE"

#' @import scales grid gtable rlang
#' @importFrom stats setNames
NULL

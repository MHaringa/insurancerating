library(testthat)
library(xml2)

test_check("xml2")

//
//  getBI_C2.h
//  
//
//  Created by Marco Enea on 18/07/17.
//
//

#ifndef getBI_C2_h
#define getBI_C2_h

#include <stdio.h>

#endif /* getBI_C2_h */
